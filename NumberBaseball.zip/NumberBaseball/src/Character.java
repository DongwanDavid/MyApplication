import java.util.*;

class Character {
	static String input;
	static char[] ch;
	
	void scan() {
		System.out.print(">>> ");
		Scanner sc = new Scanner(System.in);
		input = sc.nextLine();
	}
	
	void getCharacter() {
		ch = new char[3];
		
		for(int i=0;i<input.length();i++) {
			ch[i] = input.charAt(i);
		}
	}
}
