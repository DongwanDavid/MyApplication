class Number {
	int[] number;
	int[] input;
	
	int strikeCounter;
	int outCounter;
	int ballCounter;
	int inputCounter;
	
	static boolean isClear;
	static boolean isNinth;
	
	void setNumber() {
		number = new int[3];
		
		for(;;) {
			number[0] = (int)(Math.random()*10);
			number[1] = (int)(Math.random()*10);
			number[2] = (int)(Math.random()*10);
			
			if(number[0]!=number[1] && number[1]!=number[2] && number[2]!=number[0]) {
				break;
			}
		}
	}
	
	void getNumber() {
		input = new int[3];
		
		for(int i=0;i<input.length;i++) {
			input[i] = Character.ch[i] - '0';
		}
	}
	
	void countNumber() {
		strikeCounter = 0;
		outCounter = 0;
		ballCounter = 0;
		
		int temporary = 0;
		
		for(int i=0;i<input.length;i++) {
			if(number[i] == input[i]) {
				strikeCounter++;
			}
			
			for(int j=0;j<input.length;j++) {
				if(i != j) {
					if(number[i] == input[j]) {
						ballCounter++;
					}	
				}
				
				if(number[i] != input[j]) {
					temporary++;
					
					if(temporary == 3) {
						outCounter++;
						temporary = 0;
					}
				}
			}
		}
		
		inputCounter++;
	}
	
	void showResult() {
		if(strikeCounter != 0) {
			System.out.print(strikeCounter + "S ");
		}
		
		if(strikeCounter == 3) {
			isClear = true;
		}
		
		if(ballCounter != 0) {
			System.out.print(ballCounter  + "B ");
		}
		
		if(outCounter == 3) {
			System.out.print("OUT");
		}
		
		System.out.println();
		
		if(inputCounter == 9) {
			isNinth = true;
		}
	}
	
	void reset() {
		isClear = false;
		isNinth = false;
		inputCounter = 0;
	}
}
