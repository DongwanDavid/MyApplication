class Verifying {
	boolean isThree;
	boolean isNumber;
	boolean isDifferent;
	boolean isClear;
	boolean isNinth;
	boolean isExitOrContinue;
	boolean isExit;
	
	boolean isThree() {
		if(Character.input.length() == 3) {
			isThree = true;
		} else {
			isThree = false;
		}
		
		return isThree;
	}
	
	boolean isNumber() {
		for(int i=0;i<Character.input.length();i++) {
			char tmp = Character.input.charAt(i);
			
			if('0'<=tmp&&tmp<='9') {
				isNumber = true;
			} else {
				isNumber = false;
				break;
			}
		}
		
		return isNumber;
	}
	
	boolean isDifferent() {
		char[] tmp = new char[Character.input.length()];
		
		for(int i=0;i<Character.input.length();i++) {
			tmp[i] = Character.input.charAt(i);
		}
		
		if(tmp[0]!=tmp[1] && tmp[1]!=tmp[2] && tmp[2]!=tmp[0]) {
			isDifferent = true;
		} else {
			isDifferent = false;
		}
		
		return isDifferent;
	}
	
	boolean isClear() {
		if(Number.isClear) {
			isClear = true;
		} else {
			isClear = false;
		}
		
		return isClear;
	}
	
	boolean isNinth() {
		if(Number.isNinth) {
			isNinth = true;
		} else {
			isNinth = false;
		}
		
		return isNinth;
	}
	
	boolean isExitOrContinue() {
		if(Character.input.equals("exit") || Character.input.equals("continue")) {
			isExitOrContinue = true;
		} else {
			isExitOrContinue = false;
		}
		
		return isExitOrContinue;
	}
	
	boolean isExit() {
		if(Character.input.equals("exit")) {
			isExit = true;
		} else {
			isExit = false;
		}
		
		return isExit;
	}
}
