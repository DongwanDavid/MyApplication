public class Main {
	public static void main(String[] args) {
		Character character = new Character();
		Number    number    = new Number();
		Verifying verifying = new Verifying();
		
		System.out.println("=====Number Baseball�� �����մϴ�.=====");
		System.out.println();
		
		for(;;) {
			System.out.println("----���ϴ� ���� ������ �Է��ϼ���.----");
			number.setNumber();
			
			for(;;) {
				character.scan();
				
				if(!verifying.isThree()) {
					System.out.println("�߸��� �Է��Դϴ�.");
					continue;
				}
				
				if(!verifying.isNumber()) {
					System.out.println("�߸��� �Է��Դϴ�.");
					continue;
				}
				
				if(!verifying.isDifferent()) {
					System.out.println("�߸��� �Է��Դϴ�.");
					continue;
				}
				
				character.getCharacter();
				
				number.getNumber();
				number.countNumber();
				number.showResult();
				
				
				if(verifying.isClear()) {
					System.out.println("Clear!");
					break;
				}
				
				if(verifying.isNinth()) {
					System.out.println("Fail!");
					break;
				}
			}
			
			System.out.println("����: exit \t ���: continue");
			
			for(;;) {
				character.scan();
				
				if(verifying.isExitOrContinue()) {
					break;
				} else {
					System.out.println("�߸��� �Է��Դϴ�.");
					continue;
				}
			}
			
			
			if(verifying.isExit()) {
				break;
			} else {
				number.reset();
				continue;
			}
		}

		System.out.println();
		System.out.println("=====Number Baseball�� �����մϴ�.=====");
	}
}
